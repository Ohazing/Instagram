<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("location:login.php?pesan=login");
}
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
    <link rel="icon" href="ig.png">
    <title>Instagram</title>
  
</head>
<body>
<br>
<div class="background">
        <div class="shape"></div>
    </div>
<div align="center" class="container">
    <div class="card mb-3" style="width: 25rem;">
        <div class="card-header bg-seccondary text-dark fw-bold fs-4"></div>
        <div align="left" class="card-body">
        <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <h3>Edit Postingan</h3>
            <input type="hidden" name="no" value="<?= $post['no'] ?>">
            <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
            
            <div class="mb-3">
            <label for="" class="form-label">Gambar</label>
            <input type="file" class="form-control" name="gambar" id="" value="<?= $post['gambar'] ?>" autocomplete="off">
            </div><br>

            <div class="mb-3">
            <img src="images/<?= $post['gambar'] ?>" width="100" alt="">
            </div>

            <div class="mb-3">
            <label for="" class="form-label">Caption</label>
            <input type="text" class="form-control" name="caption" id="" value="<?= $post['caption'] ?>" >
            </div>

            <div class="mb-3">
            <label for="" class="form-label">Lokasi</label>
            <input class="form-control" type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" >
            </div>
          
                <button class="btn btn-primary" type="submit" name="update">Simpan</button>

            </form>
       
    </div>
</div>
</body>
</html>

<?php } ?>