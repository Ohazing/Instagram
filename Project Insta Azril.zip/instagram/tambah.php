<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instagram</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="ig.png">
    
</head>
<body>
<br><br>
<div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>

            <form action="proses_tambah.php" method="post" enctype="multipart/form-data">

            <h3>Postingan Baru</h3>


                <label for="formFile" class="form-">Gambar</label>
                <input class="form-" name="gambar" type="file" id="formFile" required>
  

                <label for=""  class="form-">Caption</label>
                <input class="form-" type="text" name="caption" id="" autocomplete="off">


  
                <label for=""  class="form-">Lokasi</label>
                <input class="form-" type="text" name="lokasi" id="" autocomplete="off">

                <button type="submit" name="simpan">Posting</button>
            </form>
       


</body>
</html>



