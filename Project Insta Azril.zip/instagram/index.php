<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("location:login.php?pesan=login");
}
include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NA Apparel</title>
    <link rel="stylesheet" href="index.css">
    <link rel="icon" href="./images/brand.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
</head>
<body>
<div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
<nav class="navbar sticky-top navbar-expand-lg bg-body-tertiary shadow-lg p-3 mb-5 bg-body-tertiary rounded">
  <div class="container">
  <a class="" href="#">
      <img src="./images/brand.png" alt="Bootstrap" width="150" height="75">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">

        </li>
      </ul>
    </div>
    <ul class="navbar-nav me-2">
        <li class="nav-item">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalTambah"><i class="fa-solid fa-square-plus fa-xl"></i></button>
        </li>
      </ul>
      <ul class="navbar-nav">
      <li class="nav-item">
        <a href="logout.php"><button class="btn btn-danger"><i class="fa-solid fa-right-from-bracket ">Keluar</i></button></a>
        </li>
      </ul>
  </div>
</nav>
    <div class="alert alert-light text-center fst-italic" role="alert">
      Anda login sebagai : <?= $_SESSION['login']; ?>
    </div>

    <div class="modal fade" id="modalTambah" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
      <img src="./images/brand.png" alt="Bootstrap" width="150" height="75">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">

          <div class="mb-3">
          <label for="formFile" class="form-">Gambar</label>
          <input class="form-control" name="gambar" type="file" id="formFile" required>
          </div>

          <div class="mb-3">
          <label for=""  class="form-">Caption</label>
          <input class="form-control" type="text" name="caption" id="" autocomplete="off">
          </div>

          <div class="mb-3">
          <label for=""  class="form-">Lokasi</label>
          <input class="form-control" type="text" name="lokasi" id="" autocomplete="off">
          </div>
          <button type="submit" class="btn btn-success" name="simpan">Simpan</button>
      </form>
      </div>
    </div>
  </div>
</div>
    
  <div align="center" class="container">

  <?php while($post = mysqli_fetch_assoc($query)) { ?>
   
  <div align="left" class="card shadow mb-3" style="width: 20rem;">
  <div class="img-area">
  <img src="images/<?= $post['gambar'] ?>" class="card-img-top" alt="" width="40" height="400">
  </div>
  <p class="card-header fs-4 fw-semibold bg-white"><?= $post['caption'] ?></p>
  <div class="card-body">
      <p class="card-text fst-italic"><?= $post['lokasi'] ?></p>

      <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?= $post['no'] ?>"><i class="fa-regular fa-pen-to-square fa-lg"></i></i></button>
      <a href="hapus.php?no=<?= $post['no'] ?>"><button class="btn btn-danger"><i class="fa-solid fa-trash fa-lg "></i></button></a>

    </div>
    <div class="modal fade" id="staticBackdrop<?= $post['no'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
            <img src="./images/brand.png" alt="Bootstrap" width="150" height="75">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form action="proses_edit.php" method="post" enctype="multipart/form-data">
      
            <input type="hidden" name="no" value="<?= $post['no'] ?>">
            <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
            
            <div class="mb-3">
            <label for="" class="form-label">Gambar</label>
            <input type="file" class="form-control" name="gambar" id="" value="<?= $post['gambar'] ?>" autocomplete="off">
            </div><br>

            <div class="mb-3">
            <img src="images/<?= $post['gambar'] ?>" width="100" alt="">
            </div>

            <div class="mb-3">
            <label for="" class="form-label">Caption</label>
            <input type="text" class="form-control" autocomplete="off" name="caption" id="" value="<?= $post['caption'] ?>">
            </div>

            <div class="mb-3">
            <label for="" class="form-label">Lokasi</label>
            <input class="form-control" autocomplete="off" type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" >
            </div>
            
          <button type="submit" class="btn btn-success" name="update">Simpan</button>

      </form>
      </div>
    </div>
  </div>
  </div>
  </div>
  <?php } ?>
  </div>
</body>
</html>
